class 乘法口诀表{
    public static void main (String[]args){
        int a=1;
        int b=1;
        int c;
        while (a<10){
            a=a+1;
        }
        c=a*b;
        System.out.println(a+"X"+b+"="+c);
    }
}